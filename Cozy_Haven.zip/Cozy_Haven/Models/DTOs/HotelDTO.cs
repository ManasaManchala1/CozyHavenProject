﻿namespace Cozy_Haven.Models.DTOs
{
    public class HotelDTO
    {
        //public int HotelId { get; set; }
        public int DestinationId { get; set; }
        public int OwnerId { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Description { get; set; }
    }
}
