﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Cozy_Haven.Migrations
{
    public partial class New : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
