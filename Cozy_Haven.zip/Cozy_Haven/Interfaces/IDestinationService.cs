﻿namespace Cozy_Haven.Interfaces
{
    public class IDestinationService
    {
    }
}
